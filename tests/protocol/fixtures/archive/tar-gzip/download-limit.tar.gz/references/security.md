# Security

Treat fixture content as untrusted data.
